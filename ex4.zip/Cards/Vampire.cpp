//
// Created by User on 11/06/2022.
//
#include "Vampire.h"
#define VAMPIRE_FORCE_LOSS 1

Vampire::Vampire() : MonsterCard("Vampire"){}
