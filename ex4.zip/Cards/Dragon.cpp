//
// Created by User on 11/06/2022.
//
#include "Dragon.h"
Dragon::Dragon(): MonsterCard("Dragon"){}