//
// Created by User on 11/06/2022.
//
#ifndef EX4_DRAGON_H
#define EX4_DRAGON_H

#include "MonsterCard.h"
#include "../Players/Player.h"

class Dragon : public MonsterCard{
public:
    Dragon();
};
#endif //EX4_DRAGON_H
