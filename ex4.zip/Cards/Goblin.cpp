//
// Created by User on 11/06/2022.
//
#include "Goblin.h"

Goblin::Goblin() : MonsterCard("Goblin"){}